declare module 'react-slider';
